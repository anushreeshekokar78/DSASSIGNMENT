#include <iostream>
using namespace std;

class MultipleStacks {
private:
    int arr[50];     
    int top[10];    
    int stackSize;  
    int numStacks;   
public:
    MultipleStacks(int totalStacks, int totalSize) {
        numStacks = totalStacks;
        stackSize = totalSize / totalStacks;

        for (int i = 0; i < numStacks; i++) {
            top[i] = (i * stackSize) - 1;  
        }
    }

    void push(int stackNum, int value) {
        int start = stackNum * stackSize;
        int end = start + stackSize - 1;

        if (top[stackNum] == end) {
            cout << "Stack Overflow in Stack " << stackNum << endl;
            return;
        }

        top[stackNum]++;
        arr[top[stackNum]] = value;
        cout << "Pushed " << value << " into Stack " << stackNum << endl;
    }

    void pop(int stackNum) {
        int start = stackNum * stackSize;

        if (top[stackNum] < start) {
            cout << "Stack Underflow in Stack " << stackNum << endl;
            return;
        }

        int value = arr[top[stackNum]];
        top[stackNum]--;
        cout << "Popped " << value << " from Stack " << stackNum << endl;
    }

   
    void display(int stackNum) {
        int start = stackNum * stackSize;

        if (top[stackNum] < start) {
            cout << "Stack " << stackNum << " is empty." << endl;
            return;
        }

        cout << "Stack " << stackNum << " elements: ";
        for (int i = start; i <= top[stackNum]; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    int totalStacks, totalSize;

    cout << "Enter total size of array: ";
    cin >> totalSize;

    cout << "Enter number of stacks: ";
    cin >> totalStacks;

    MultipleStacks ms(totalStacks, totalSize);

    int choice, stackNum, value;

    do {
        cout << "\n--- Menu ---\n";
        cout << "1. Push\n";
        cout << "2. Pop\n";
        cout << "3. Display\n";
        cout << "4. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter stack number (0 - " << totalStacks - 1 << "): ";
                cin >> stackNum;
                cout << "Enter value to push: ";
                cin >> value;
                ms.push(stackNum, value);
                break;

            case 2:
                cout << "Enter stack number (0 - " << totalStacks - 1 << "): ";
                cin >> stackNum;
                ms.pop(stackNum);
                break;

            case 3:
                cout << "Enter stack number (0 - " << totalStacks - 1 << "): ";
                cin >> stackNum;
                ms.display(stackNum);
                break;

            case 4:
                cout << "Exiting program." << endl;
                break;

            default:
                cout << "Invalid choice! Try again." << endl;
        }
    } while (choice != 4);

    return 0;
}
