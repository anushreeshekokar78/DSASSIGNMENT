#include <iostream>
#include <stack>
#include <string>
#include <cctype>
using namespace std;

int precedence(char op) {
    if (op == '^') return 3;
    if (op == '*' || op == '/') return 2;
    if (op == '+' || op == '-') return 1;
    return 0;
}

bool isOperator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/' || c == '^');
}

string infixToPostfix(const string &expr) {
    stack<char> st;
    string postfix;

    for (char c : expr) {
        if (isspace(c)) continue; 

        // If operand, directly add to postfix
        if (isalnum(c)) {
            postfix += c;
        }
        // If '(', push to stack
        else if (c == '(') {
            st.push(c);
        }
        // If ')', pop until '('
        else if (c == ')') {
            while (!st.empty() && st.top() != '(') {
                postfix += st.top();
                st.pop();
            }
            if (!st.empty()) st.pop();  
        }
       
        else if (isOperator(c)) {
            while (!st.empty() && precedence(st.top()) >= precedence(c) && st.top() != '(') {
                postfix += st.top();
                st.pop();
            }
            st.push(c);
        }
    }

    // Pop any remaining operators
    while (!st.empty()) {
        postfix += st.top();
        st.pop();
    }

    return postfix;
}

int main() {
    string infix;
    cout << "Enter an infix expression: ";
    getline(cin, infix);

    if (infix.empty()) {
        infix = "a-b*c-d/e+f"; 
        cout << "Using default expression: " << infix << endl;
    }

    string postfix = infixToPostfix(infix);

    cout << "Postfix Expression: " << postfix << endl;
    return 0;
}
