#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 300   // matrix size (you can change this)

int main() {
    int A[N][N], B[N][N], C[N][N];
    int i, j, k;
    clock_t start, end;
    double time;

    // Initialize matrices with random numbers
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            A[i][j] = rand() % 10;
            B[i][j] = rand() % 10;
        }
    }

    // ---------- Row-Major Multiplication ----------
    start = clock();
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            C[i][j] = 0;
            for (k = 0; k < N; k++) {
                C[i][j] += A[i][k] * B[k][j];  // good: row of A, col of B
            }
        }
    }
    end = clock();
    time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Row-major order time: %.3f sec\n", time);

    // ---------- Column-Major Multiplication ----------
    start = clock();
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            C[i][j] = 0;
            for (k = 0; k < N; k++) {
                C[i][j] += A[i][k] * B[j][k];  // bad: accessing column of B
            }
        }
    }
    end = clock();
    time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Column-major order time: %.3f sec\n", time);

    return 0;
}
