#include <iostream>
#include <string>
using namespace std;

struct Node {
    int prn;
    string name;
    Node* next;
};

class SinglyLinkedList {
    Node* head;

public:
    SinglyLinkedList() {
        head = NULL;
    }

    // Add President (at beginning)
    void addPresident(int prn, string name) {
        Node* newNode = new Node{prn, name, head};
        head = newNode;
    }

    // Add Secretary (at end)
    void addSecretary(int prn, string name) {
        Node* newNode = new Node{prn, name, NULL};
        if (head == NULL) {
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next != NULL) temp = temp->next;
        temp->next = newNode;
    }

    // Add member after a given PRN
    void addMember(int prn, string name, int afterPRN) {
        Node* temp = head;
        while (temp && temp->prn != afterPRN) temp = temp->next;
        if (!temp) {
            cout << "Member not found!\n";
            return;
        }
        Node* newNode = new Node{prn, name, temp->next};
        temp->next = newNode;
    }

    // Delete member by PRN
    void deleteMember(int prn) {
        if (!head) return;

        // If President is to be deleted
        if (head->prn == prn) {
            Node* temp = head;
            head = head->next;
            delete temp;
            return;
        }

        Node* temp = head;
        while (temp->next && temp->next->prn != prn) temp = temp->next;
        if (!temp->next) {
            cout << "Member not found!\n";
            return;
        }

        Node* toDelete = temp->next;
        temp->next = toDelete->next;
        delete toDelete;
    }

    // Count members
    int countMembers() {
        int count = 0;
        Node* temp = head;
        while (temp) {
            count++;
            temp = temp->next;
        }
        return count;
    }

    // Display members
    void display() {
        Node* temp = head;
        cout << "\nClub Members:\n";
        while (temp) {
            cout << temp->prn << " - " << temp->name << endl;
            temp = temp->next;
        }
    }

    // Concatenate with another list
    void concatenate(SinglyLinkedList& other) {
        if (head == NULL) {
            head = other.head;
            return;
        }
        Node* temp = head;
        while (temp->next) temp = temp->next;
        temp->next = other.head;
    }
};

// ---------------- Main ----------------
int main() {
    SinglyLinkedList divA, divB;

    // Division A members
    divA.addPresident(1, "Alice");
    divA.addSecretary(2, "Bob");

    // Division B members
    divB.addPresident(3, "Charlie");
    divB.addSecretary(4, "David");

    cout << "Division A: ";
    divA.display();

    cout << "\nDivision B: ";
    divB.display();

    // Concatenate both lists
    divA.concatenate(divB);
    cout << "\nAfter Concatenation (Div A + Div B): ";
    divA.display();

    cout << "\nTotal Members = " << divA.countMembers() << endl;

    // Delete a member
    divA.deleteMember(2);
    cout << "\nAfter deleting Bob: ";
    divA.display();

    return 0;
}
