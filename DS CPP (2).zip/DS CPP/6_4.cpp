#include <iostream>
using namespace std;

class TwoQueues {
private:
    int size;
    int *queue1, *queue2;
    int front1, rear1, front2, rear2;

public:
    TwoQueues(int n) {
        size = n;
        queue1 = new int[size];
        queue2 = new int[size];
        front1 = rear1 = -1;
        front2 = rear2 = -1;
    }

    // Add element to a selected queue
    void enqueue(int qNumber, int value) {
        if (qNumber == 1) {
            if (rear1 == size - 1) {
                cout << "Queue 1 is full! Cannot add element.\n";
                return;
            }
            if (front1 == -1) front1 = 0;
            queue1[++rear1] = value;
            cout << "Added " << value << " to Queue 1.\n";
        } else if (qNumber == 2) {
            if (rear2 == size - 1) {
                cout << "Queue 2 is full! Cannot add element.\n";
                return;
            }
            if (front2 == -1) front2 = 0;
            queue2[++rear2] = value;
            cout << "Added " << value << " to Queue 2.\n";
        } else {
            cout << "Invalid Queue Number!\n";
        }
    }

    // Remove element from a selected queue
    void dequeue(int qNumber) {
        if (qNumber == 1) {
            if (front1 == -1 || front1 > rear1) {
                cout << "Queue 1 is empty! Cannot delete element.\n";
                return;
            }
            cout << "Deleted " << queue1[front1++] << " from Queue 1.\n";
            if (front1 > rear1) front1 = rear1 = -1; // Reset queue
        } 
        else if (qNumber == 2) {
            if (front2 == -1 || front2 > rear2) {
                cout << "Queue 2 is empty! Cannot delete element.\n";
                return;
            }
            cout << "Deleted " << queue2[front2++] << " from Queue 2.\n";
            if (front2 > rear2) front2 = rear2 = -1; // Reset queue
        } 
        else {
            cout << "Invalid Queue Number!\n";
        }
    }

    void display(int qNumber) {
        if (qNumber == 1) {
            if (front1 == -1) {
                cout << "Queue 1 is empty!\n";
                return;
            }
            cout << "Queue 1 elements: ";
            for (int i = front1; i <= rear1; i++) {
                cout << queue1[i] << " ";
            }
            cout << endl;
        } 
        else if (qNumber == 2) {
            if (front2 == -1) {
                cout << "Queue 2 is empty!\n";
                return;
            }
            cout << "Queue 2 elements: ";
            for (int i = front2; i <= rear2; i++) {
                cout << queue2[i] << " ";
            }
            cout << endl;
        } 
        else {
            cout << "Invalid Queue Number!\n";
        }
    }
    
    ~TwoQueues() {
        delete[] queue1;
        delete[] queue2;
    }
};

int main() {
    int n;
    cout << "Enter the maximum size of each queue: ";
    cin >> n;

    TwoQueues tq(n);
    int choice, qNumber, value;

    do {
        cout << "\n--- Two Queues Menu ---\n";
        cout << "1. Add to Queue\n";
        cout << "2. Delete from Queue\n";
        cout << "3. Display Queue\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter Queue Number (1 or 2): ";
                cin >> qNumber;
                cout << "Enter value to add: ";
                cin >> value;
                tq.enqueue(qNumber, value);
                break;

            case 2:
                cout << "Enter Queue Number (1 or 2): ";
                cin >> qNumber;
                tq.dequeue(qNumber);
                break;

            case 3:
                cout << "Enter Queue Number (1 or 2): ";
                cin >> qNumber;
                tq.display(qNumber);
                break;

            case 4:
                cout << "Exiting program. Goodbye!\n";
                break;

            default:
                cout << "Invalid choice! Please try again.\n";
        }
    } while (choice != 4);

    return 0;
}
