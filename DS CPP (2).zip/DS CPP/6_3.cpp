#include <iostream>
#include <queue>
#include <string>
using namespace std;

int main() {
    queue<string> passengers;  
    int choice;
    string name;

    do {
        cout << "\n--- Ticket Agent Menu ---\n";
        cout << "1. Add Passenger to Queue\n";
        cout << "2. Show Passenger at Front\n";
        cout << "3. Remove Passenger from Front\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: // Add a passenger
                cout << "Enter passenger name: ";
                cin.ignore(); 
                getline(cin, name);
                passengers.push(name);
                cout << "Passenger '" << name << "' added to the queue.\n";
                break;

            case 2: // Display passenger at front
                if (passengers.empty()) {
                    cout << "No passengers are waiting.\n";
                } else {
                    cout << "Passenger at front: " << passengers.front() << endl;
                }
                break;

            case 3: // Remove passenger from front
                if (passengers.empty()) {
                    cout << "No passengers to remove.\n";
                } else {
                    cout << "Removing passenger: " << passengers.front() << endl;
                    passengers.pop();
                }
                break;

            case 4: // Exit
                cout << "Total passengers left in queue: " << passengers.size() << endl;
                cout << "Exiting the system. Goodbye!\n";
                break;

            default:
                cout << "Invalid choice! Please try again.\n";
        }
    } while (choice != 4);

    return 0;
}
