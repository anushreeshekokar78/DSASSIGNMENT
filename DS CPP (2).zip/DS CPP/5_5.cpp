#include <iostream>
#include <stack>
#include <string>
using namespace std;

// Function to perform basic arithmetic operations
int applyOperation(int a, int b, char op) {
    switch (op) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': return a / b; 
    }
    return 0;
}

// Function to evaluate a postfix expression
int evaluatePostfix(const string &expr) {
    stack<int> s;

    for (char ch : expr) {
        // If it's a digit, push it as integer
        if (isdigit(ch)) {
            s.push(ch - '0'); // convert char to int
        }
        // If it's an operator, pop two values and apply the operation
        else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
            if (s.size() < 2) {
                cout << "Invalid expression!" << endl;
                return -1;
            }
            int val2 = s.top(); s.pop();
            int val1 = s.top(); s.pop();
            int result = applyOperation(val1, val2, ch);
            s.push(result);
        }
    }

    // Final result should be the only element in the stack
    return s.empty() ? -1 : s.top();
}

int main() {
    string postfix;
    cout << "Enter a postfix expression: ";
    cin >> postfix;

    int result = evaluatePostfix(postfix);
    if (result != -1)
        cout << "Result: " << result << endl;

    return 0;
}
