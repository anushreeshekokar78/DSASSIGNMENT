#include <stdio.h>

int main() {
    char str1[100], str2[100], copy[100], reverse[100], concat[200];
    int i, j, len = 0;

    printf("Enter first string: ");
    scanf("%s", str1);

    printf("Enter second string: ");
    scanf("%s", str2);

    // 1. Length
    for (i = 0; str1[i] != '\0'; i++);
    len = i;
    printf("\nLength of first string = %d", len);

    // 2. Copy
    for (i = 0; str1[i] != '\0'; i++) {
        copy[i] = str1[i];
    }
    copy[i] = '\0';
    printf("\nCopy of first string = %s", copy);

    // 3. Reverse
    for (i = 0; str1[i] != '\0'; i++);
    len = i;
    for (j = 0, i = len - 1; i >= 0; i--, j++) {
        reverse[j] = str1[i];
    }
    reverse[j] = '\0';
    printf("\nReverse of first string = %s", reverse);

    // 4. Concatenation
    for (i = 0; str1[i] != '\0'; i++) {
        concat[i] = str1[i];
    }
    for (j = 0; str2[j] != '\0'; j++, i++) {
        concat[i] = str2[j];
    }
    concat[i] = '\0';
    printf("\nConcatenation of first and second string = %s", concat);

    return 0;
}
