#include <iostream>
#include <string>
using namespace std;

struct Node {
    string customerName;
    Node* next;
};

class CallQueue {
private:
    Node* front; 
    Node* rear;  

public:
    CallQueue() {
        front = rear = nullptr;
    }

    // Enqueue: Add new customer call
    void enqueue(const string& name) {
        Node* newNode = new Node();
        newNode->customerName = name;
        newNode->next = nullptr;

        if (rear == nullptr) {
            front = rear = newNode; // First customer
        } else {
            rear->next = newNode;
            rear = newNode;
        }
        cout << "Call from '" << name << "' added to the queue.\n";
    }

    // Dequeue: Serve the first customer
    void dequeue() {
        if (front == nullptr) {
            cout << "No calls in the queue. Waiting for calls...\n";
            return;
        }
        Node* temp = front;
        cout << "Serving call from '" << temp->customerName << "'.\n";
        front = front->next;

        if (front == nullptr)
            rear = nullptr;

        delete temp;
    }

    void display() {
        if (front == nullptr) {
            cout << "No calls in the queue.\n";
            return;
        }
        cout << "Calls waiting in the queue: ";
        Node* temp = front;
        while (temp != nullptr) {
            cout << temp->customerName << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    ~CallQueue() {
        while (front != nullptr) {
            Node* temp = front;
            front = front->next;
            delete temp;
        }
    }
};

int main() {
    CallQueue callCenter;
    int choice;
    string name;

    do {
        cout << "\n--- Call Center Menu ---\n";
        cout << "1. Add Incoming Call (Enqueue)\n";
        cout << "2. Serve Customer Call (Dequeue)\n";
        cout << "3. Display Waiting Calls\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter customer name: ";
                cin.ignore(); 
                getline(cin, name);
                callCenter.enqueue(name);
                break;

            case 2:
                callCenter.dequeue();
                break;

            case 3:
                callCenter.display();
                break;

            case 4:
                cout << "Exiting system. Goodbye!\n";
                break;

            default:
                cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 4);

    return 0;
}
