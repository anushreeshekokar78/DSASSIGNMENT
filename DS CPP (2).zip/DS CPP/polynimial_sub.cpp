#include <iostream>
#include <cstdlib>
using namespace std;

// Node structure
struct Node {
    int coeff;   // coefficient
    int pow;     // power of x
    Node* next;  // pointer to next node
};

// Function to create a new node
Node* createNode(int coeff, int pow) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->coeff = coeff;
    newNode->pow = pow;
    newNode->next = NULL;
    return newNode;
}

// Function to insert node at end
void insert(Node** head, int coeff, int pow) {
    Node* newNode = createNode(coeff, pow);
    if (*head == NULL) {
        *head = newNode;
        return;
    }
    Node* temp = *head;
    while (temp->next != NULL) temp = temp->next;
    temp->next = newNode;
}

// Function to display polynomial
void display(Node* head) {
    while (head != NULL) {
        cout << head->coeff << "x^" << head->pow;
        head = head->next;
        if (head != NULL) cout << " + ";
    }
    cout << "\n";
}

// Recursive function to subtract poly2 from poly1 (poly1 - poly2)
Node* subtractPolynomials(Node* poly1, Node* poly2) {
    // If poly1 is NULL → return -poly2
    if (poly1 == NULL) {
        // Negate remaining poly2
        Node* result = NULL;
        while (poly2 != NULL) {
            insert(&result, -(poly2->coeff), poly2->pow);
            poly2 = poly2->next;
        }
        return result;
    }

    // If poly2 is NULL → return poly1
    if (poly2 == NULL) return poly1;

    Node* result = NULL;

    if (poly1->pow > poly2->pow) {
        result = createNode(poly1->coeff, poly1->pow);
        result->next = subtractPolynomials(poly1->next, poly2);
    }
    else if (poly1->pow < poly2->pow) {
        result = createNode(-(poly2->coeff), poly2->pow);
        result->next = subtractPolynomials(poly1, poly2->next);
    }
    else { // powers are equal
        result = createNode(poly1->coeff - poly2->coeff, poly1->pow);
        result->next = subtractPolynomials(poly1->next, poly2->next);
    }

    return result;
}

// Main function
int main() {
    Node* poly1 = NULL;
    Node* poly2 = NULL;
    Node* diff = NULL;

    // Polynomial 1: 5x^2 + 4x^1 + 2
    insert(&poly1, 5, 2);
    insert(&poly1, 4, 1);
    insert(&poly1, 2, 0);

    // Polynomial 2: 5x^1 + 5
    insert(&poly2, 5, 1);
    insert(&poly2, 5, 0);

    cout << "Polynomial 1: ";
    display(poly1);

    cout << "Polynomial 2: ";
    display(poly2);

    diff = subtractPolynomials(poly1, poly2);

    cout << "Difference (Polynomial 1 - Polynomial 2): ";
    display(diff);

    return 0;
}