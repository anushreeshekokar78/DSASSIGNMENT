#include <iostream>
#include <queue>
#include <string>
using namespace std;

struct Patient {
    int id;
    string name;
};

class Clinic {
private:
    queue<Patient> patientQueue;
    int nextId;

public:
    Clinic() {
        nextId = 1;
    }

    void checkIn(string name) {
        Patient p;
        p.id = nextId++;
        p.name = name;
        patientQueue.push(p);
        cout << "Patient " << p.name << " (ID: " << p.id << ") checked in successfully.\n";
    }

    // Assign the next patient to a doctor
    void assignDoctor() {
        if (patientQueue.empty()) {
            cout << "No patients are waiting.\n";
            return;
        }

        Patient nextPatient = patientQueue.front();
        patientQueue.pop();
        cout << "Assigning Patient " << nextPatient.name
             << " (ID: " << nextPatient.id << ") to a doctor.\n";
    }

    // Display all waiting patients
    void displayQueue() {
        if (patientQueue.empty()) {
            cout << "No patients are waiting.\n";
            return;
        }

        cout << "Patients waiting in queue:\n";
        queue<Patient> temp = patientQueue;
        while (!temp.empty()) {
            cout << "ID: " << temp.front().id << " | Name: " << temp.front().name << endl;
            temp.pop();
        }
    }
};

int main() {
    Clinic clinic;
    int choice;
    string name;

    do {
        cout << "\n--- Medical Clinic Menu ---\n";
        cout << "1. Check-in a new patient\n";
        cout << "2. Assign next patient to doctor\n";
        cout << "3. Display all waiting patients\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter patient's name: ";
                cin.ignore(); 
                getline(cin, name);
                clinic.checkIn(name);
                break;

            case 2:
                clinic.assignDoctor();
                break;

            case 3:
                clinic.displayQueue();
                break;

            case 4:
                cout << "Exiting program. Goodbye!\n";
                break;

            default:
                cout << "Invalid choice! Please try again.\n";
        }
    } while (choice != 4);

    return 0;
}
