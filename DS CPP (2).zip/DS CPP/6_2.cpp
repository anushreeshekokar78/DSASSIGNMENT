#include <iostream>
using namespace std;

class CircularQueue {
private:
    int front, rear, size;
    int *queue;

public:
    CircularQueue(int n) {
        size = n;
        queue = new int[size];
        front = rear = -1;
    }

    // Check if queue is full
    bool isFull() {
        return (front == 0 && rear == size - 1) || (front == rear + 1);
    }

    // Check if queue is empty
    bool isEmpty() {
        return front == -1;
    }

    // Add order to the queue
    void placeOrder(int orderID) {
        if (isFull()) {
            cout << "Cannot place order. The system is full!\n";
            return;
        }
        if (front == -1) {
            front = 0;
        }
        rear = (rear + 1) % size;
        queue[rear] = orderID;
        cout << "Order " << orderID << " placed successfully!\n";
    }

    // Serve the next order
    void serveOrder() {
        if (isEmpty()) {
            cout << "No orders to serve.\n";
            return;
        }
        cout << "Serving Order " << queue[front] << ".\n";

        if (front == rear) {
            // Only one element
            front = rear = -1;
        } else {
            front = (front + 1) % size;
        }
    }

    // Display all pending orders
    void displayOrders() {
        if (isEmpty()) {
            cout << "No pending orders.\n";
            return;
        }

        cout << "Pending Orders: ";
        int i = front;
        while (true) {
            cout << queue[i] << " ";
            if (i == rear) break;
            i = (i + 1) % size;
        }
        cout << endl;
    }

    ~CircularQueue() {
        delete[] queue;
    }
};

int main() {
    int n;
    cout << "Enter the maximum number of orders: ";
    cin >> n;

    CircularQueue pizzaParlour(n);
    int choice, orderID = 1;

    do {
        cout << "\n--- Pizza Parlour Menu ---\n";
        cout << "1. Place Order\n";
        cout << "2. Serve Order\n";
        cout << "3. Display Pending Orders\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                pizzaParlour.placeOrder(orderID++);
                break;
            case 2:
                pizzaParlour.serveOrder();
                break;
            case 3:
                pizzaParlour.displayOrders();
                break;
            case 4:
                cout << "Exiting the system. Goodbye!\n";
                break;
            default:
                cout << "Invalid choice! Please try again.\n";
        }
    } while (choice != 4);

    return 0;
}
