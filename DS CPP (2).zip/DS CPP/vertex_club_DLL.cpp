#include <iostream>
#include <string>
using namespace std;

struct Node {
    int prn;
    string name;
    Node* prev;
    Node* next;
};

class DoublyLinkedList {
    Node* head;

public:
    DoublyLinkedList() {
        head = NULL;
    }

    // Add President (at beginning)
    void addPresident(int prn, string name) {
        Node* newNode = new Node{prn, name, NULL, head};
        if (head != NULL) head->prev = newNode;
        head = newNode;
    }

    // Add Secretary (at end)
    void addSecretary(int prn, string name) {
        Node* newNode = new Node{prn, name, NULL, NULL};
        if (head == NULL) {
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next != NULL) temp = temp->next;
        temp->next = newNode;
        newNode->prev = temp;
    }

    // Add member after given PRN
    void addMember(int prn, string name, int afterPRN) {
        Node* temp = head;
        while (temp && temp->prn != afterPRN) temp = temp->next;
        if (!temp) {
            cout << "Member not found!\n";
            return;
        }
        Node* newNode = new Node{prn, name, temp, temp->next};
        if (temp->next) temp->next->prev = newNode;
        temp->next = newNode;
    }

    // Delete member by PRN
    void deleteMember(int prn) {
        if (!head) return;

        Node* temp = head;

        // If head itself is to be deleted (President)
        if (temp->prn == prn) {
            head = temp->next;
            if (head) head->prev = NULL;
            delete temp;
            cout << "Deleted member with PRN " << prn << endl;
            return;
        }

        while (temp && temp->prn != prn) temp = temp->next;
        if (!temp) {
            cout << "Member not found!\n";
            return;
        }

        if (temp->next) temp->next->prev = temp->prev;
        if (temp->prev) temp->prev->next = temp->next;
        delete temp;

        cout << "Deleted member with PRN " << prn << endl;
    }

    // Count members
    int countMembers() {
        int count = 0;
        Node* temp = head;
        while (temp) {
            count++;
            temp = temp->next;
        }
        return count;
    }

   
    void display() {
        Node* temp = head;
        cout << "\nClub Members (Forward):\n";
        while (temp) {
            cout << temp->prn << " - " << temp->name << endl;
            temp = temp->next;
        }
    }

    
    void displayReverse() {
        if (!head) {
            cout << "List is empty!\n";
 
             return;
        }
        Node* temp = head;
        // Go to last node
        while (temp->next) temp = temp->next;

        cout << "\nClub Members (Reverse):\n";
        while (temp) {
            cout << temp->prn << " - " << temp->name << endl;
            temp = temp->prev;
        }
    }

    // Concatenate with another list
    void concatenate(DoublyLinkedList& other) {
        if (head == NULL) {
            head = other.head;
            return;
        }
        Node* temp = head;
        while (temp->next) temp = temp->next;
        temp->next = other.head;
        if (other.head) other.head->prev = temp;
    }
};


int main() {
    DoublyLinkedList divA, divB;

    // Division A members
    divA.addPresident(1, "Sanika");
    divA.addSecretary(2, "Radha");
    divA.addSecretary(3, "Yash");

    // Division B members
    divB.addPresident(4, "Chaitali");
    divB.addSecretary(5, "Adhnya");

    cout << "Division A: ";
    divA.display();

    cout << "\nDivision B: ";
    divB.display();

    // Concatenate both lists
    divA.concatenate(divB);
    cout << "\nAfter Concatenation (Div A + Div B): ";
    divA.display();

    // Show reverse order
    divA.displayReverse();

    cout << "\nTotal Members = " << divA.countMembers() << endl;

    // Delete a member
    divA.deleteMember(2);  // delete Radha
    cout << "\nAfter deleting Bob: ";
    divA.display();
    

    // Show reverse after deletion
    divA.displayReverse();

    return 0;
}
