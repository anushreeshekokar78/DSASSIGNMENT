#include <iostream>
#include <cstdlib>
using namespace std;

// Node structure
struct Node {
    int coeff;   // coefficient
    int pow;     // power of x
    Node* next;  // pointer to next node
};

// Function to create a new node
Node* createNode(int coeff, int pow) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->coeff = coeff;
    newNode->pow = pow;
    newNode->next = NULL;
    return newNode;
}

// Function to insert node at end
void insert(Node** head, int coeff, int pow) {
    Node* newNode = createNode(coeff, pow);
    if (*head == NULL) {
        *head = newNode;
        return;
    }
    Node* temp = *head;
    while (temp->next != NULL) temp = temp->next;
    temp->next = newNode;
}

// Function to display polynomial
void display(Node* head) {
    while (head != NULL) {
        cout << head->coeff << "  " << head->pow;
        head = head->next;
        if (head != NULL) cout << " + ";
    }
    cout << "\n";
}

// Function to add two polynomials
Node* addPolynomials(Node* poly1, Node* poly2) {
    Node* result = NULL;
    Node* temp1 = poly1;
    Node* temp2 = poly2;

    while (temp1 != NULL && temp2 != NULL) {
        if (temp1->pow == temp2->pow) {
            insert(&result, temp1->coeff + temp2->coeff, temp1->pow);
            temp1 = temp1->next;
            temp2 = temp2->next;
        }
        else if (temp1->pow > temp2->pow) {
            insert(&result, temp1->coeff, temp1->pow);
            temp1 = temp1->next;
        }
        else {
            insert(&result, temp2->coeff, temp2->pow);
            temp2 = temp2->next;
        }
    }

    // If poly1 has remaining terms
    while (temp1 != NULL) {
        insert(&result, temp1->coeff, temp1->pow);
        temp1 = temp1->next;
    }

    // If poly2 has remaining terms
    while (temp2 != NULL) {
        insert(&result, temp2->coeff, temp2->pow);
        temp2 = temp2->next;
    }

    return result;
}

// Main function
int main() {
    Node* poly1 = NULL;
    Node* poly2 = NULL;
    Node* sum = NULL;

    // Example: 5x^2 + 4x^1 + 2
    insert(&poly1, 5, 2);
    insert(&poly1, 4, 1);
    insert(&poly1, 2, 0);

    // Example: 5x^1 + 5
    insert(&poly2, 5, 1);
    insert(&poly2, 5, 0);

    cout << "Polynomial 1: ";
    display(poly1);

    cout << "Polynomial 2: ";
    display(poly2);

    sum = addPolynomials(poly1, poly2);

    cout << "Sum of Polynomials: ";
    display(sum);

    return 0;
}