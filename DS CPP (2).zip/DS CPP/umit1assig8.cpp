#include <iostream>
#include <string>
using namespace std;

struct Student {
    string name;
    int marks;
};

int main() {
    int n;
    cout << "Enter number of students: ";
    cin >> n;

    Student s[100];  // assuming max 100 students

    // Input student details
    for (int i = 0; i < n; i++) {
        cout << "Enter name of student " << i + 1 << ": ";
        cin >> s[i].name;
        cout << "Enter marks of " << s[i].name << ": ";
        cin >> s[i].marks;
    }

    // Bubble sort in descending order (topper first)
    for (int i = 0; i < n - 1; i++) {
        cout << "\nPass " << i + 1 << ":" << endl;
        for (int j = 0; j < n - i - 1; j++) {
            if (s[j].marks < s[j + 1].marks) {
                // swap
                Student temp = s[j];
                s[j] = s[j + 1];
                s[j + 1] = temp;
            }

            // Display current list after each comparison
            cout << "  Step " << j + 1 << ": ";
            for (int k = 0; k < n; k++)
                cout << s[k].name << "(" << s[k].marks << ") ";
            cout << endl;
        }
    }

    // Assign roll numbers (topper = roll no. 1)
    cout << "\nFinal Roll Number Assignment:\n";
    for (int i = 0; i < n; i++) {
        cout << "Roll No. " << i + 1 << " -> " << s[i].name
             << " (Marks: " << s[i].marks << ")\n";
    }

    return 0;
}
