#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    string address;
    string mail;
    string mobile;

public:
    void getDetails() {
        cout << "\nEnter Employee Name: ";
        cin >> name;

        cout << "Enter Employee ID: ";
        cin >> id;

        cout << "Enter Address: ";
        cin >> address;

        cout << "Enter Mail ID: ";
        cin >> mail;

        cout << "Enter Mobile No: ";
        cin >> mobile;
    }

    void displayDetails() {
        cout << "\nEmployee Name: " << name;
        cout << "\nEmployee ID: " << id;
        cout << "\nAddress: " << address;
        cout << "\nMail ID: " << mail;
        cout << "\nMobile No: " << mobile;
    }
};

class Salary : public Employee {
protected:
    float bp, da, hra, pf, club, gross, net;

public:
    void getSalary() {
        cout << "Enter Basic Pay (BP): ";
        cin >> bp;

        da = 0.52 * bp;
        hra = 0.27 * bp;
        pf = 0.12 * bp;
        club = 0.001 * bp;

        gross = bp + da + hra;
        net = gross - pf - club;
    }

    void displaySalary() {
        cout << "\nBasic Pay: " << bp;
        cout << "\nDA: " << da;
        cout << "\nHRA: " << hra;
        cout << "\nPF: " << pf;
        cout << "\nStaff Club Fund: " << club;
        cout << "\nGross Salary: " << gross;
        cout << "\nNet Salary: " << net;
    }
};

// Derived roles
class Programmer : public Salary {
public:
    void show() {
        cout << "\n\n Pay Slip for Programmer ";
        displayDetails();
        displaySalary();
    }
};

class TeamLead : public Salary {
public:
    void show() {
        cout << "\n\n Pay Slip for Team Lead ";
        displayDetails();
        displaySalary();
    }
};

class AsstProjectManager : public Salary {
public:
    void show() {
        cout << "\n\n Pay Slip for Assistant Project Manager ";
        displayDetails();
        displaySalary();
    }
};

class ProjectManager : public Salary {
public:
    void show() {
        cout << "\n\n Pay Slip for Project Manager ";
        displayDetails();
        displaySalary();
    }
};

int main() {
    int choice;

    do {
        cout << "\n\n EMPLOYEE PAY SLIP MENU ";
        cout << "\n1. Programmer";
        cout << "\n2. Team Lead";
        cout << "\n3. Assistant Project Manager";
        cout << "\n4. Project Manager";
        cout << "\n5. Exit";
        cout << "\nEnter your choice: ";
        cin >> choice;

        switch(choice) {
            case 1: {
                Programmer p;
                p.getDetails();
                p.getSalary();
                p.show();
                break;
            }
            case 2: {
                TeamLead t;
                t.getDetails();
                t.getSalary();
                t.show();
                break;
            }
            case 3: {
                AsstProjectManager a;
                a.getDetails();
                a.getSalary();
                a.show();
                break;
            }
            case 4: {
                ProjectManager m;
                m.getDetails();
                m.getSalary();
                m.show();
                break;
            }
            case 5:
                cout << "\nExiting program...";
                break;
            default:
                cout << "\nInvalid choice!";
        }
    } while(choice != 5);

      return 0;
}