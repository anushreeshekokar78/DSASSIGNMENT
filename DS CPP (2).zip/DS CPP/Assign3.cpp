#include <iostream>
#include <string>
using namespace std;

class Student {
    int rollNo;
    string name;
    int marks[5];
    float percentage;
    string grade;

public:
    Student(int r, string n, int m[5]) {
        rollNo = r;
        name = n;
        int sum = 0;
        for (int i = 0; i < 5; i++) {
            marks[i] = m[i];
            sum += marks[i];
        }
        percentage = sum / 5.0;  
        calcGrade();
    }

    
    ~Student() {
        cout << "\nDestructor called for " << name << endl;
    }

    
    void calcGrade() {
        if (percentage >= 60)
            grade = "First Class";
        else if (percentage >= 50)
            grade = "Second Class";
        else if (percentage >= 40)
            grade = "Pass";
        else
            grade = "Fail";
    }

    
    void display() {
        cout << "\nRoll No: " << rollNo;
        cout << "\nName: " << name;
        cout << "\nPercentage: " << percentage;
        cout << "\nGrade: " << grade << endl;
    }
};

int main() {
    int roll, marks[5];
    string name;

    cout << "Enter Roll No: ";
    cin >> roll;
    cout << "Enter Name: ";
    cin >> name;

    cout << "Enter marks of 5 subjects: ";
    for (int i = 0; i < 5; i++)
        cin >> marks[i];

    
    Student s1(roll, name, marks);

    
    s1.display();
    return 0;
}