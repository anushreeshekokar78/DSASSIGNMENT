#include <stdio.h>

int main() {
    int n, i, j;

    printf("Enter order of magic square (n): ");
    scanf("%d", &n);

    int square[50][50] = {0};

    if (n < 3) {
        printf("Magic square not possible for n < 3\n");
        return 0;
    }

    // ---- ODD order magic square ----
    if (n % 2 == 1) {
        int num, row = 0, col = n / 2;

        for (num = 1; num <= n * n; num++) {
            square[row][col] = num;
            row--;
            col++;

            if (num % n == 0) {
                row += 2;
                col--;
            } else {
                if (row < 0) row = n - 1;
                if (col == n) col = 0;
            }
        }
    }
    // ---- DOUBLY EVEN magic square ----
    else if (n % 4 == 0) {
        int num = 1;
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                square[i][j] = num++;
            }
        }

        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                if ((i % 4 == j % 4) || ((i % 4 + j % 4) == 3)) {
                    square[i][j] = n * n + 1 - square[i][j];
                }
            }
        }
    } else {
        printf("This program does not handle n = %d (singly even)\n", n);
        return 0;
    }

    // ---- Print Magic Square ----
    printf("\nMagic Square of order %d:\n", n);
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            printf("%4d", square[i][j]);
        }
        printf("\n");
    }

     // Verify sum 
    int magicConst = n * (n * n + 1) / 2;
    printf("\nMagic Constant = %d\n", magicConst);

    return 0;
}
