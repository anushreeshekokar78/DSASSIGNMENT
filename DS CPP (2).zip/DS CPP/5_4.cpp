#include <iostream>
#include <stack>
#include <string>
using namespace std;

// Function to check if two brackets are matching
bool isMatchingPair(char open, char close) {
    return (open == '(' && close == ')') ||
           (open == '{' && close == '}') ||
           (open == '[' && close == ']');
}

// Function to check if the string is balanced
bool isBalanced(const string &str) {
    stack<char> s;

    for (char ch : str) {
        // If it's an opening bracket, push it onto the stack
        if (ch == '(' || ch == '{' || ch == '[') {
            s.push(ch);
        }
        // If it's a closing bracket
        else if (ch == ')' || ch == '}' || ch == ']') {
            // If stack is empty or top does not match, it's unbalanced
            if (s.empty() || !isMatchingPair(s.top(), ch)) {
                return false;
            }
            s.pop(); 
        }
    }

    return s.empty();
}

int main() {
    string input;
    cout << "Enter a string with brackets: ";
    cin >> input;

    if (isBalanced(input))
        cout << "The string is Balanced." << endl;
    else
        cout << "The string is Not Balanced." << endl;

    return 0;
}
