#include <iostream>
using namespace std;

struct Node {
    int price;
    Node* next;
    
    Node(int value) {
        price = value;
        next = nullptr;
    }
};

class StockPriceStack {
private:
    Node* top;  
public:
    StockPriceStack() {
        top = nullptr;
    }

    // Function to check if the stack is empty
    bool isEmpty() {
        return top == nullptr;
    }

    void record(int price) {
        Node* newNode = new Node(price);
        newNode->next = top;
        top = newNode;
        cout << "Recorded price: " << price << endl;
    }

    int remove() {
        if (isEmpty()) {
            cout << "No stock prices to remove!" << endl;
            return -1;
        }
        int removedPrice = top->price;
        Node* temp = top;
        top = top->next;
        delete temp;
        cout << "Removed latest price: " << removedPrice << endl;
        return removedPrice;
    }

    int latest() {
        if (isEmpty()) {
            cout << "No stock prices recorded yet!" << endl;
            return -1;
        }
        cout << "Latest price: " << top->price << endl;
        return top->price;
    }
    ~StockPriceStack() {
        while (!isEmpty()) {
            remove();
        }
    }
};

int main() {
    StockPriceStack tracker;
    int choice, price;

    do {
        cout << "\n--- Stock Price Tracker Menu ---\n";
        cout << "1. Record a new stock price\n";
        cout << "2. Remove the latest stock price\n";
        cout << "3. View the latest stock price\n";
        cout << "4. Check if no prices are recorded\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter stock price: ";
                cin >> price;
                tracker.record(price);
                break;

            case 2:
                tracker.remove();
                break;

            case 3:
                tracker.latest();
                break;

            case 4:
                if (tracker.isEmpty())
                    cout << "No prices recorded yet." << endl;
                else
                    cout << "Prices are available in the tracker." << endl;
                break;

            case 5:
                cout << "Exiting the program." << endl;
                break;

            default:
                cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 5);

    return 0;
}
